############################################################
# subroutines for editing alignment, blast out
# Hong Qin
# To use this module, put following lines
#  use lib '/shar/lib/perl/';     use Align; 
#
############################################################



############################################################
# Date:		Author:
# Usage: 
# Description:
# Tested in ?
# Used in ?


##############################################################
1;

